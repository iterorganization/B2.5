!!-----------------------------------------------------------------------------
!! DOCUMENTATION (doxygen 1.8.8):
!>      @author
!>      Dejan Penko
!!
!>      @page b2uw_b2mod b2_ual_write_b2mod
!>      @section b2uw_b2mod_desc   Description
!!      b2_ual_write_b2mod code is used to generate b2_ual_write_b2mod.exe
!!      (main program), which is a post-processor for b2.
!!      The code reads the plasma grid
!!      geometry ( full geometry descriptions of all available grid subsets )
!!      and plasma state (electron density/temperature, ion temperature,
!!      velocity etc.). The code then writes the obtained data to IDS database
!!      with the use of b2mod scripts that utilize IMAS GGD Grid Service
!!      Library routines.
!!
!!      @note   More on the b2_ual_writers is available in SOLPS-GUI
!!              documentation under section <b> IMAS HOWTO </b>.
!!
!!      @note   A short video tutorial on the use of the B2.5 writer is
!!              available <a href="https://youtu.be/5IuADXPAgkQ">here</a>.
!!
!!      @section b2uw_b2mod_cpo2ids Mapping CPO -> IDS
!!      Most B2.5 routines were originally developed to work solely with ITM
!!      CPOs. Those same routines were modified or created anew, providing
!!      necessary tools for working with IMAS IDSs.
!!      Since CPO and IDS data structure is not the same a lot of proper
!!      adjustments had to be made, mostly in modules
!!      @ref b2uw_ualio_grid_desc "b2mod_ual_io_grid" and
!!      @ref b2uw_ualio_desc      "b2mod_ual_io".
!!
!!
!!      @subsection b2uw_b2mod_cpo2ids_constants Constants, classes etc.
!!      Below are listed CPO constants, classes etc. and corresponding IDS
!!      ones that were used in IMAS IDS B2.5 routines.
!!
!!      CPO                                     | IDS
!!      -------------------------------         | ------------------
!!      CLASS_NODE = (/ 0, 0 /)                 | IDS_CLASS_NODE = 1
!!      CLASS_RZ_EDGE = (/ 1, 0 /)              | IDS_CLASS_RZ_EDGE = 2
!!      CLASS_PHI_EDGE = (/ 0,10 /)             | IDS_CLASS_PHI_EDGE = 2
!!      CLASS_POLOIDALRADIAL_FACE = (/ 1, 1 /)  | IDS_CLASS_POLOIDALRADIAL_FACE = 2
!!      CLASS_TOROIDAL_FACE = (/ 2, 0 /)        | IDS_CLASS_TOROIDAL_FACE = 2
!!      CLASS_CELL = (/ 2, 1 /)                 | IDS_CLASS_CELL = 3
!!
!!      <b> Grid subset IDs </b>:
!!
!!      B2.5 ITM routines use grid subset IDs (B2_SUBGRID_UNSPECIFIED,
!!      B2_SUBGRID_NODES, B2_SUBGRID_CELLS etc.) defined in
!!      @ref b2uw_ualio_grid_desc "b2mod_ual_io_grid.F90", while B2.5 IDS
!!      uses grid subset IDs defined in IMAS GGD (ids_grid_common.f90).
!!
!!      @subsection b2uw_b2mod_cpo2ids_nodes Data tree nodes
!!      Below are listed CPO nodes and corresponding IDS nodes to which the
!!      data was written instead.
!!
!!      CPO edge.grid. ...              | IDS edge_profiles.ggd(:).grid. ...
!!      ------------------------------- | -------------------------------------
!!      spaces(:).coordtype             | space(:).coordinates_type
!!      spaces(:).objects               | space(:).objects_per_dimension(:).object
!!      spaces(:).objects(:).geo        | space(:).objects_per_dimension(:).object(:).geometry
!!      spaces(:).objects(:).boundary   | space(:).objects_per_dimension(:).object(:).boundary
!!      spaces(:).objects(:).neighbour  | space(:).objects_per_dimension(:).object(:).boundary(:).neighbours
!!      spaces(:).xpoints               | No node for data on x-points was found
!!      subgrids                        | grid_subset
!!
!!      CPO edge. ...           | IDS
!!      ----------------------- | ---------------------------------------------
!!      fluid.ne.value          | edge_profiles.ggd(:).electrons.density
!!      fluid.ne.flux           | edge_transport.model(:).ggd(:).electrons.particles.flux
!!      fluid.ne.source         | edge_sources.source(:).ggd(:).electrons.particles
!!      fluid.ni.value          | edge_profiles.ggd(:).ion(:).density
!!      fluid.ni.flux           | edge_transport.model(:).ggd(:).ion(:).particles.flux
!!      fluid.ni.source         | edge_sources.source(:).ggd(:).ion(:).particles
!!      fluid.vi(:).comps(1)    | edge_profiles.ggd(:).ion(:).velocity(:).radial
!!      fluid.vi(:).comps(2)    | edge_profiles.ggd(:).ion(:).velocity(:).poloidal
!!      fluid.vi(:).comps(3)    | edge_profiles.ggd(:).ion(:).velocity(:).toroidal
!!      fluid.vi(:).align(:)    | Probably not required as the leaf label refers to vector component itself
!!      fluid.vi(:).alignid     | Refers to the label of the node velocity(:) leaf
!!      fluid.te(:).value       | edge_profiles.ggd(:).electrons.temperature
!!      fluid.te(:).flux        | edge_transport.model(:).ggd(:).electrons.energy.flux
!!      fluid.ti(:).value       | edge_profiles.ggd(:).ion(:).temperature
!!      fluid.ti(:).flux        | edge_transport.model(:).ggd(:).ion(:).energy.flux
!!      fluid.po.value          | edge_profiles.ggd(:).phi_potential
!!      fluid.te_aniso.comps(1) | edge_profiles.ggd(:).e_field.poloidal
!!      fluid.te_aniso.comps(2) | edge_profiles.ggd(:).e_field.radial
!!      fluid.te_aniso.comps(3) | edge_profiles.ggd(:).e_field.toroidal
!!      fluid.te_aniso.comps(4) | edge_profiles.ggd(:).e_field.diamagnetic
!!
!!      @note   In the future, IDS data structure nodes that correspond to
!!              flux data fields are to be moved from edge_transport IDS to
!!              edge_profiles IDS.
!!
!!      @section b2uw_b2mod_env Compiling and setting the environment
!!      In order compile the B2.5 writer code use the commands below:
!!
!!      @verbatim
!!          cd $HOME/solps-iter
!!          tcsh
!!          source setup.csh
!!          cd modules/B2.5
!!          make ids
!!      @endverbatim
!!
!!      @note   At the time of writing this manual IMAS module
!!              imas/3.13.0/ual/3.6.3 was used. This IMAS module provides
!!              also GGD support as it includes IMAS GGD library routines
!!              (Fortran90).
!!
!!      @note   b2_ual_write and b2_ual_write_gsl are OUTDATED codes, but
!!              were left in the repository for documentation purposes and as
!!              and extra examples.
!!
!!      @subsection b2uw_b2mod_run Running the code:
!!      The examples are available on ITER portal:
!!      <a href="https://portal.iter.org/departments/POP/CM/IMAS/Forms/AllItems.aspx?RootFolder=%2Fdepartments%2FPOP%2FCM%2FIMAS%2FSOLPS-ITER%2FExamples">B2.5 examples link</a>
!!
!!      In terminal navigate to directory containing the case required data files
!!      (b2fgmtry, b2fstate etc.) and run the following command:
!!
!!      @verbatim
!!          $HOME/solps-iter/modules/B2.5/builds/standalone.$HOST_NAME.$COMPILER/b2_ual_write_b2mod.exe <shot> <run> <username> <device> <version>
!!      @endverbatim
!!
!!      The arguments marked with < ... > are the parameters of the IDS database
!!      where the data is to be stored:
!!          - \b shot:      The shot number of the database being created
!!          - \b run:       The run number of the database being created
!!          - \b username:  Creator/owner of the IMAS IDS database
!!          - \b device:    Device name of the IMAS IDS database
!!                          (i. e. solps-iter, iter, aug)
!!          - \b version:   Major version of the IMAS IDS database
!!
!!      Example of the command:
!!      @verbatim
!!          $HOME/solps-iter/modules/B2.5/builds/standalone.$HOST_NAME.$COMPILER/b2_ual_write_b2mod.exe 100 7 penkod solps-iter 3
!!      @endverbatim
!!
!!      \b References:
!!          - @ref b2uw_b2mod_prog "b2_ual_write_b2mod file reference"
!!          - @ref b2uw_ualio_grid_desc "b2mod_ual_io_grid module "
!!          - @ref b2uw_ualio_desc      "b2mod_ual_io module".
!!
!!-----------------------------------------------------------------------------

!!-----------------------------------------------------------------------------
!>      @section b2uw_b2mod_prog Program b2_ual_write_b2mod
!!      References:
!!          - @ref b2uw_b2mod "b2_ual_write_b2mod main page"
!!
!!      @subsection b2uw_b2mod_det   Details
!!      For more information see also routine \b b2cdca.
!!
!!      The complete program performs post-processing of the
!!      result of a b2 calculation.
!!      This program unit opens and closes the input/output units, and
!!      may perform some other system-dependent operations.

!!
!!      The input units are:
!!          - ninp(0): formatted; provides output control parameters.
!!          - ninp(1): un*formatted; provides the geometry.
!!          - ninp(2): un*formatted; provides the run parameters.
!!          - ninp(3): un*formatted; provides the plasma state.
!!          - ninp(4): unformatted; provides the detailed plasma state.
!!          - ninp(5): formatted; provides the run switches.
!!          - ninp(6): un*formatted; provides the atomic data.
!!
!!      The output units are:
!!          - nout(0): formatted; provides printed output.
!!
!!      @note   See routine b2cdca for the meaning of "un*formatted".
!!
!!      @subsection b2uw_b2mod_pv    Parameters/variables
!!      @note   see also routine \b b2cdcv
!!
!!      @param  device - Device name of the IMAS IDS database
!!              (i. e. solps-iter, iter, aug)
!!      @param  edge_profiles - IDS designed to store data on edge plasma
!!              profiles  (includes the scrape-off layer and possibly part
!!              of the confined plasma)
!!      @param  edge_sources - IDS designed to store data on edge plasma
!!              sources. Energy terms correspond to the full kinetic energy
!!              equation (i.e. the energy flux takes into account the energy
!!              transported by the particle flux)
!!      @param  edge_transport - IDS designed to store data on edge plasma
!!              transport. Energy terms correspond to the full kinetic energy
!!              equation (i.e. the energy flux takes into account the energy
!!              transported by the particle flux)
!!      @param  idx - The returned identifier to be used in the subsequent
!!                    data access operation
!!      @param  run - The run number of the database being created
!!      @param  shot - The shot number of the database being created
!!      @param  treename - the name of the IMAS IDS database,
!!              (i.e. "edge_profiles" (mandatory) )
!!      @param  username - Creator/owner of the IMAS IDS database
!!      @param  version - Major version of the IMAS IDS database
!!
!!      @subsection b2uw_b2mod_eind  Error indicators
!!      In case an error condition is detected, a call is made to the
!!      routine \b xerrab. This causes an error message to be printed,
!!      after which the program halts.
!!
!!      @subsection b2uw_b2mod_syx     Exceptional syntax explanation
!!      @code
!!          ! IGNORE    !! syntax used to ignore this module in list
!!                      !! dependency when compiling the code
!!      @endcode
!!
!!-----------------------------------------------------------------------------

program b2_ual_write_b2mod

    use b2mod_main
    use b2mod_grid_mapping
    use b2mod_ual_io
    use ids_schemas     ! IGNORE
                        !! These are the Fortran type definitions for the
                        !! Physics Data Model
    use ids_routines    ! IGNORE
                        !! These are the Access Layer routines + management of
                        !! IDS structures
    use ids_assert      ! IGNORE
    use ids_grid_common &       ! IGNORE
        & , IDS_COORDTYPE_R => COORDTYPE_R    &
        & , IDS_COORDTYPE_Z => COORDTYPE_Z
        ! &   GRID_UNDEFINED  => B2_GRID_UNDEFINED
    use ids_string              ! IGNORE
    use ids_grid_subgrid        ! IGNORE
    use ids_grid_objectlist     ! IGNORE
    use ids_grid_examples       ! IGNORE
    use ids_grid_unstructured   ! IGNORE
    use ids_grid_structured     ! IGNORE

    implicit none

    !! Local variables
    character(len=24) :: treename   !< The name of the IMAS IDS database
        !< (i.e. "edge_profiles" (mandatory) )
    character(len=24) :: username   !< Creator/owner of the IMAS IDS database
    character(len=24) :: device     !< Device name of the IMAS IDS database
        !< (i. e. solps-iter, iter, aug)
    character(len=24) :: version    !< Major version of the IMAS IDS database
    integer :: idx  !< The returned identifier to be used in the subsequent
        !< data access operation
    integer :: i    !< Iterator
    integer :: shot !< The shot number of the database being created
    integer :: run  !< The run number of the database being created
    integer :: num_step     !< Number of steps
    integer :: narg     !< Total Number of input arguments (shot, run etc.)
    integer :: cptArg
    type(ids_edge_profiles) :: edge_profiles    !< IDS designed to store data on
        !< edge plasma profiles  (includes the scrape-off layer and possibly
        !< part of the confined plasma)
    type (ids_edge_sources) :: edge_sources !< IDS designed to store
        !< data on edge plasma sources. Energy terms correspond to the full
        !< kinetic energy equation (i.e. the energy flux takes into account
        !< the energy transported by the particle flux)
    type (ids_edge_transport) :: edge_transport !< IDS designed to store
        !< data on edge plasma transport. Energy terms correspond to the
        !< full kinetic energy equation (i.e. the energy flux takes into
        !< account the energy transported by the particle flux)

    !! Dummy variables
    character(len=24) :: shot_string
    character(len=24) :: run_string
    character(len=24) :: num_step_string
    character(len=24) :: argName

    !! Check if supposed new file already exists and delete it
    call checkFileAndDelete( "b2fparam" )
    call checkFileAndDelete( "b2mn.prt" )
    call checkFileAndDelete( "b2fstate" )
    call checkFileAndDelete( "b2fmovie" )
    call checkFileAndDelete( "b2ftrace" )
    call checkFileAndDelete( "b2ftrack" )

    !! Set default value for number of steps
    num_step = -1
    version = "3"

    !! Check if arguments are found
    narg = command_argument_count()

    if( narg > 0 ) then
        !! Loop across arguments and allocate proper values to variables
        do cptArg = 1, narg
            call get_command_argument( cptArg, argName )
            select case( adjustl( argName ) )
                case("--shot")
                    call get_command_argument( cptArg + 1, shot_string )
                    !! Transform dummy string variable to integer
                    read( shot_string, *) shot
                case("--run")
                    call get_command_argument( cptArg + 1, run_string )
                    !! Transform dummy string variable to integer
                    read( run_string, *) run
                case("--username")
                    call get_command_argument( cptArg + 1, username )
                case("--device")
                    call get_command_argument( cptArg + 1, device )
                case("--version")
                    call get_command_argument( cptArg + 1, version )
                case("--numstep")
                    call get_command_argument( cptArg + 1, num_step_string )
                    !! Transform dummy string variable to integer
                    read( num_step_string, *) num_step
            end select
        end do
    !! If not at least shot, run, username and device were defined display
    !! the error message and and a full command example
    else if( narg .lt. 8 ) then
        write(0,*) "ERROR! In order to run b2_ual_write_b2mod input IDS&
            & shot, run, user, device and version variables must&
            & be defined. Example (terminal): "
        write(0,*) "$SOLPSTOP/modules/B2.5/builds/standalone.ITER.ifort64/&
            &b2_ual_write_b2mod.exe --shot 1 --run 1 --username penkod&
            &  --device solps-iter --version 3 --step 250"
        call exit(0)
    else
        write(0,*) "ERROR! In order to run b2_ual_write_b2mod input IDS&
            & shot, run, user, device and version variables must&
            & be defined. Example (terminal): "
        write(0,*) "$SOLPSTOP/modules/B2.5/builds/standalone.ITER.ifort64/&
            &b2_ual_write_b2mod.exe --shot 1512 --run 6 --username penkod&
            &  --device solps-iter --version 3 --step 250"
        call exit(0)
    end if

    !! Run main b2 routine to process and read the b2 data
    write(0,*) "Running b2mn_init"
    call b2mn_init
    write(0,*) "b2mn_init completed"

    !! If steps were defined then run the b2mn_step routine for the number of
    !! steps
    if( num_step .ge. -1 ) then
        write(0,*) "Running b2mn_step(", num_step, ")"
        write(0,*) "num_step: ", num_step
        call b2mn_step( num_step )
    end if
    write(0,*) "b2mn_step() completed"

    ! write(0,*) " Running b2mn_fin"
    ! call b2mn_fin
    ! write(0,*) "b2mn_fin completed"

    treename = 'ids'

    !! Process B2.5 data and set it to IMAS IDS
    write(*,*) "START B25_process_ids"
    call B25_process_ids( edge_profiles, edge_sources, edge_transport )

    !! Create Write the set data to IDSs
    write(*,*) "START put_ids_edge"
    call put_ids_edge( edge_profiles, edge_sources, edge_transport, treename,   &
        &   shot, run, idx, username, device, version )

    ! call read_ids(treename, shot, run, idx, username, &
    !                                     & device, version )

contains

    !> Subroutine intended to check if supposed new file already exists. If
    !! the file exists it deletes it.
    subroutine checkFileAndDelete( fileName )
        character(len=*), intent(in) :: fileName    !< Name of the file to be
                                                    !< checked
        !! Internal variables
        integer :: stat
        logical :: file_exists

        inquire( file=fileName, exist=file_exists )
        if ( file_exists ) then
            write(*,*) "Deleting old ", fileName
            open(unit=1234, iostat=stat, file=fileName, status='old')
            if (stat == 0) close(1234, status='delete')
        endif

    end subroutine

    !> Subroutine used to put data to edge_profiles, edge_sources and
    !! edge_transport IDSs.
    subroutine put_ids_edge( edge_profiles, edge_sources, edge_transport,   &
            &   treename, shot, run, idx, username, device, version )
        type(ids_edge_profiles), intent(inout)  :: edge_profiles    !< IDS
            !< designed to store data on edge plasma profiles  (includes the
            !< scrape-off layer and possibly part of the confined plasma)
        type (ids_edge_sources), intent(inout)  :: edge_sources     !< IDS
            !< designed to store data on edge plasma sources. Energy terms
            !< correspond to the full kinetic energy equation (i.e. the energy
            !< flux takes into account the energy transported by the particle
            !< flux)
        type (ids_edge_transport), intent(inout)  :: edge_transport !< IDS
            !< designed to store  data on edge plasma transport. Energy terms
            !< correspond to the full kinetic energy equation (i.e. the energy
            !< flux takes into account the energy transported by the particle
            !< flux)
        character(len=24), intent(in) :: treename   !< The name of the IMAS IDS database
            !< (i.e. "edge_profiles" (mandatory) )
        integer, intent(in) :: shot !< The shot number of the database being created
        integer, intent(in) :: run  !< The run number of the database being created
        integer, intent(in) :: idx  !< The returned identifier to be used in the subsequent
            !< data access operation
        character(len=24), intent(in) :: username   !< Creator/owner of the IMAS IDS
            !< database
        character(len=24), intent(in) :: device     !< Device name of the IMAS IDS database
            !< (i. e. solps-iter, iter, aug)
        character(len=24), intent(in) :: version    !< Major version of the IMAS IDS
            !< database

        !! Set data to edge_profiles IDS
        write(0,*) "Writing to edge_profiles, edge_sources and edge_transport IDS"

        !! Create and modify new shot/run
        call imas_create_env( treename, shot, run, 0, 0, idx, username, &
            device, version )

        !! Or open and modify existing shot/run (might work much faster than
        !! imas_create_env)
        ! call imas_open_env('treename', shot, run, idx, username, device, version )

        !! Put data to IDS
        ! call ids_put_slice( idx, "edge_profiles", edge_profiles )
        ! call ids_put_slice( idx, "edge_transport", edge_sources )
        ! call ids_put_slice( idx, "edge_transport", edge_transport )
        call ids_put( idx, "edge_profiles", edge_profiles )
        call ids_put( idx, "edge_sources", edge_sources )
        call ids_put( idx, "edge_transport", edge_transport )

        !! Close IDS
        call ids_deallocate( edge_profiles )
        call ids_deallocate( edge_sources )
        call ids_deallocate( edge_transport )
        call imas_close( idx )

        write(0,*) "IDS write finished"

    end subroutine put_ids_edge

    !> Example subroutine for reading edge_profiles IDS
    !! with Fortran90
    subroutine read_ids( treename, shot, run, idx, username, device, version )
        character(len=24), intent(in) :: treename   !< The name of the IMAS IDS database
        integer, intent(in) :: shot !< The shot number of the database being created
        integer, intent(in) :: run  !< The run number of the database being created
        integer, intent(in) :: idx  !< The returned identifier to be used in the subsequent
        character(len=24), intent(in) :: username   !< Creator/owner of the IMAS IDS database
        character(len=24), intent(in) :: device !< Device name of the IMAS IDS database
            !< (i. e. solps-iter, iter, aug)
        character(len=24), intent(in) :: version    !< Major version of the IMAS IDS database
        !! Internal variables
        integer :: gridSubset_index !< >Grid subset base index
        type(ids_edge_profiles) :: edge_profiles    !< IDS designed to store
            !< data in edge plasma profiles  (includes the scrape-off layer and
            !<  possibly part of the confined plasma)

        gridSubset_index = 3

        !! Open input datafile from local database
        write (0,*) "Started reading input IDS", idx, shot, run

        call imas_open_env('treename', shot, run, idx, username, device, version )
        call ids_get(idx, "edge_profiles", edge_profiles)

        write(0,*) "homogeneous_time = ",   &
            &   edge_profiles%ids_properties%homogeneous_time
        write(0,*) "Grid subset 3 name = ", edge_profiles%ggd(1)%grid%  &
            &   grid_subset(gridSubset_index)%identifier%name
        write(0,*) "Grid subset 3 index = ", edge_profiles%ggd(1)%grid% &
            &   grid_subset(gridSubset_index)%identifier%index
        ! write(0,*) "Time = ", edge_profiles%time(1)
        call ids_deallocate( edge_profiles )
        call imas_close( idx )
        write (0,*) "Finished reading input IDS"

    end subroutine read_ids

end program b2_ual_write_b2mod

!!!Local Variables:
!!! mode: f90
!!! End:
