      character*32 :: git_version_B25 = 
     & 'B2.5-3.0.5-1355-g7e896617-dirty'
